﻿using ProjektEvidencePojisteni;

/// <summary>
/// Proměnná určující zda chce uživatel pokračovat
/// </summary>
bool pokracovat = true;
/// <summary>
/// Vytvoření instance uživatelského rozhraní
/// </summary>
EvidencePojisteni evidencePojisteni = new EvidencePojisteni(); 
UzivatelskeRozhrani uzivatelskeRozhrani = new UzivatelskeRozhrani(evidencePojisteni); 
while (pokracovat)
{
    /// <summary>
    /// Vypsání menu
    /// </summary>
    Console.WriteLine("-------------------------");
    Console.WriteLine("Evidence pojištěných");
    Console.WriteLine("-------------------------");
    Console.WriteLine("Vyber akci:");
    Console.WriteLine("1 - Přidat nového pojištěného");
    Console.WriteLine("2 - Vypsat všechny pojištěné");
    Console.WriteLine("3 - Vyhledat pojištěného");
    Console.WriteLine("4 - Konec");
    /// <summary>
    /// Vstup uživatele pro volbu v menu
    /// </summary>
    char volba = Console.ReadKey().KeyChar;
    Console.WriteLine();
    /// <summary>
    /// Podmínka pro výběr akce
    /// </summary>
    switch (volba)
    {
        case '1':
            uzivatelskeRozhrani.VytvorPojistence();
            break;
        case '2':
            evidencePojisteni.VypisSeznamPojistencu();
            break;
        case '3':
            evidencePojisteni.VyhledejPojistence(uzivatelskeRozhrani.ZadejJmeno(), uzivatelskeRozhrani.ZadejPrijmeni());
            break;
        case '4':
            pokracovat = false;
            break;
        default:
            Console.WriteLine("Neplatná volba, zadejte prosím číslo 1 až 4");
            break;
    }
    if (pokracovat)
    {
        Console.WriteLine();
        Console.WriteLine("Pro pokračování stiskněte libovolnou klávesu");
        Console.ReadKey();
    }
}
    
