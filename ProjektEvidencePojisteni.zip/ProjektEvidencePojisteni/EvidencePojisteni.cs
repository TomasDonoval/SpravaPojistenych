﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektEvidencePojisteni
{
    class EvidencePojisteni
    {
        /// <summary>
        /// Kolekce pojistenců
        /// </summary>
        public List<Pojistenec> pojistenci =  new List<Pojistenec>();
        /// <summary>
        /// Přidá pojištěnce do kolekce pojištěnců
        /// </summary>
        public void PridejPojistence(Pojistenec pojistenec)
        {
            pojistenci.Add(pojistenec);

        }
        /// <summary>
        /// Vypíše všechny pojištěnce v kolekci pojištěnců
        /// </summary>
        public void VypisSeznamPojistencu()
        {
            Console.WriteLine();
            if (pojistenci.Count == 0)
            {
                Console.WriteLine("Zatím není přidán, žádný pojištěnec.");
            }
            else
                foreach (var pojistenec in pojistenci)
                {
                    Console.WriteLine($"Jméno: {pojistenec.Jmeno}, Příjmení: {pojistenec.Prijmeni}, Věk: {pojistenec.Vek}, Telefonní Číslo: {pojistenec.TelefonniCislo}");
                }
        }
        /// <summary>
        /// Vyhledá pojištěného podle jména a příjmení
        /// </summary>
        public void VyhledejPojistence(string zadaneJmeno, string zadanePrijmeni)
        {
            Console.WriteLine();
            foreach (var pojistenec in pojistenci)
            {
                if (pojistenec.Jmeno.ToLower() == zadaneJmeno.ToLower() && pojistenec.Prijmeni.ToLower() == zadanePrijmeni.ToLower())
                {
                    Console.WriteLine($"Jméno: {pojistenec.Jmeno}, Příjmení: {pojistenec.Prijmeni}, Věk: {pojistenec.Vek}, Telefonní Číslo: {pojistenec.TelefonniCislo}");
                }
            }
            Console.WriteLine("Pojištěnec nebyl nalezen.");
        }
    }
}
