﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektEvidencePojisteni
{
    class UzivatelskeRozhrani
    {
        private EvidencePojisteni evidencePojisteni;
        /// <summary>
        /// Konstruktor, který příjmá instanci EvidencePojisteni
        /// </summary>
        public UzivatelskeRozhrani(EvidencePojisteni evidencePojisteni) 
        {
            this.evidencePojisteni = evidencePojisteni;
        }

        /// <summary>
        /// Metoda pro vytvoření pojištěnce
        /// </summary>
        public void VytvorPojistence()
        {
            string jmeno = ZadejJmeno();
            string prijmeni = ZadejPrijmeni();
            int vek = ZadejVek();
            string telefonniCislo = ZadejTelefonniCislo();

            Pojistenec pojistenec = new Pojistenec(jmeno, prijmeni, vek, telefonniCislo);
            evidencePojisteni.PridejPojistence(pojistenec);

            Console.WriteLine();
            Console.WriteLine("Data byla uložena");
        }

        /// <summary>
        /// Nechá uživatele zadat jméno
        /// </summary>
        public string ZadejJmeno()
        {
            Console.WriteLine("Zadejte jméno");
            string jmeno = Console.ReadLine();
            while (string.IsNullOrWhiteSpace(jmeno))
            {
                Console.WriteLine("Pole jméno nesmí být prázdné. Zadejte prosím platné jméno.");
                jmeno = Console.ReadLine();
            }
            return jmeno;
        }
        /// <summary>
        /// Nechá uživatele zadat příjmení
        /// </summary>
        public string ZadejPrijmeni()
        {
            Console.WriteLine("Zadejte příjmení");
            string prijmeni = Console.ReadLine();
            while (string.IsNullOrWhiteSpace(prijmeni))
            {
                Console.WriteLine("Pole příjmení nesmí být prázdné. Zadejte prosím platné příjmení.");
                prijmeni = Console.ReadLine();
            }
            return prijmeni;
        }
        /// <summary>
        /// Nechá uživatele zadat telefonní číslo
        /// </summary>
        public string ZadejTelefonniCislo()
        {
            Console.WriteLine("Zadejte telefonní číslo");
            string telefonniCislo = Console.ReadLine();
            while (string.IsNullOrWhiteSpace(telefonniCislo))
            {
                Console.WriteLine("Pole telefon nesmí být prázdné. Zadejte prosím platné telefonní číslo.");
                telefonniCislo = Console.ReadLine();
            }
            return telefonniCislo;
        }
        /// <summary>
        /// Nechá uživatele zadat věk
        /// </summary>
        public int ZadejVek()
        {
            Console.WriteLine("Zadejte věk");
            int vek;
            while (!int.TryParse(Console.ReadLine(), out vek))
            {
                Console.WriteLine("Zdejte prosím věk ve tvaru čísla.");
            }
            return vek;
        }
    }
}
