﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjektEvidencePojisteni
{
    class Pojistenec
    {
        /// <summary>
        /// Jmeno pojištěnce
        /// </summary>
        public string Jmeno { get; set; }
        /// <summary>
        /// Příjmení pojištěnce
        /// </summary>
        public string Prijmeni { get; set; }
        /// <summary>
        /// Věk pojištěnce
        /// </summary>
        public int Vek { get ; set; }
        /// <summary>
        /// Telefonní číslo pojištěnce
        /// </summary>
        public string TelefonniCislo { get; set;}
        /// <summary>
        /// Inicializace instance
        /// </summary>
        /// <param name="jmeno">Jmeno pojištěnce</param>
        /// <param name="prijmeni">Prijmení pojištěnce</param>
        /// <param name="vek">Věk pojištěnce</param>
        /// <param name="telefonniCislo">Telefonní číslo pojištěnce</param>
        public Pojistenec(string jmeno,string prijmeni,int vek,string telefonniCislo) 
        {
            Jmeno = jmeno;
            Prijmeni = prijmeni;
            Vek = vek;
            TelefonniCislo = telefonniCislo;
        }
        public override string ToString()
        {
            return $"{Jmeno} {Prijmeni} {Vek} {TelefonniCislo}";
        }

    }
}
